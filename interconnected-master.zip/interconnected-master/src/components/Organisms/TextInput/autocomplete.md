Libs usadas neste componente:
- lucide-react
- tailwind-merge
- tailwind-scrollbar
``` bash
    npm install tailwind-merge
    npm install lucide-react
    npm install --save-dev tailwind-scrollbar

```

Caso tenha uma preferência por outra lib de icons ou queira mudar p ícone fique a vontade para alterar o componente `Clear`